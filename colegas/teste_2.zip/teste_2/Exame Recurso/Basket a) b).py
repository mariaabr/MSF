# -*- coding: utf-8 -*-
"""
Created on Thu Jun  2 22:20:46 2022

@author: hf_co
"""

import matplotlib.pyplot as plt
import numpy as np

#*  Volante de Badmington
#*COM RESISTENCIA 

dt = 0.0001  
angle1 = np.radians(45)
g1 = -9.8
t1 = np.arange(0,3+dt, dt)
y1 = np.zeros(t1.size)
x1 = np.zeros(t1.size)
vx1 = np.zeros(t1.size)
vy1 = np.zeros(t1.size)
v01 = 10 #* A velocidade passa a ser 200km por hora

D1 = -g1/(20)**2
y1[0] = 2.5    #* inicializa na posição 3

vx1[0] = v01*np.cos(angle1)
vy1[0] = v01*np.sin(angle1)

for i in range(t1.size-1):
    v1 = np.sqrt(vx1[i]**2 + vy1[i]**2)
    ax1 = -D1*v1*vx1[i]
    ay1 = g1-D1*v1*vy1[i]
    vx1[i+1] = vx1[i] + ax1 * dt
    vy1[i+1] = vy1[i] + ay1 * dt
    x1[i+1] = x1[i] + vx1[i] * dt
    y1[i+1] = y1[i]+ vy1[i] * dt
    if y1[i+1] < 0:
        break

t1 = t1[:i+2]
x1 = x1[:i+2]
y1 = y1[:i+2]
vx1 = vx1[:i+2]
vy1 = vy1[:i+2]


aux1 = np.argmin(abs(y1[-2:]))
tsolosi1 = t1[-2:][aux1]
xsolosi1 = x1[-2:][aux1]
print("COM RES")
print("Instante de altura máxima")
print(t1[np.where(y1 == np.amax(y1))] )
print("Altura máxima")
print(np.amax(y1))
print("Instante de regresso ao solo") #* exercicio b
print(tsolosi1)
print("Maximo alcançe") #*exercicio b
print(xsolosi1)


plt.plot(x1,y1, label="Com Res")
#plt.plot(t,y,label="ty")
#plt.plot(t,x,label="tx")
plt.legend()
plt.grid()
plt.show()
