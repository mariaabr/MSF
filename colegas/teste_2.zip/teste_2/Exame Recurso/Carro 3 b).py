# -*- coding: utf-8 -*-
"""
Created on Thu Jun  2 19:43:34 2022

@author: hf_co
"""

# potencia do ciclista Pcic = (Cres/2)*A*Par*v**2 + umg) * v :: sendo que o u e o cres. do alcatrao 
print(((0.9/2)*3*1.225*(90/3.6)**2 + 0.004*1200*9.8)*25)