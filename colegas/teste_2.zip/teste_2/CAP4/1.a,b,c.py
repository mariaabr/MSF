# -*- coding: utf-8 -*-
"""
Created on Mon May 30 22:17:24 2022

@author: tiago
"""

import numpy as np
import matplotlib.pyplot as plt

dt=0.00001
tf=1.00
n=np.int(tf/dt+0.1)

t=np.linspace(0,tf,n)


g=9.80      # m/s**2
vt=100*1000/3600  # m/s
vel0=100*1000/3600  # m/s
theta=10*np.pi/180  # rad
v0x=vel0*np.cos(theta)
v0y=vel0*np.sin(theta)
x0=0
y0=0


tsolo=2*v0y/g           #tempo que demora a chegar ao solo 
xsolo=2*v0x*v0y/g       #alcance
ym=y0+0.5*v0y**2/g      #altura max   
tm=v0y/g                #tempo que demora a atingir a altura max    


print(' exato sem resist.: tm, ym,tsolo, xsolo =',tm,ym,tsolo,xsolo)


xs=x0+v0x*t
ys=y0+v0y*t-0.5*g*t**2



plt.xlabel( 'x(t) (m)' )
plt.ylabel( 'y(t) (m)' )
plt.plot(xs,ys,'-',label='Analitico sem resistencia')
plt.show()

