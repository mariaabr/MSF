# -*- coding: utf-8 -*-
"""
Created on Tue May 31 14:38:54 2022

@author: tiago
"""
import numpy as np
import  matplotlib.pyplot as plt

dt = 0.01  
g = -9.8    #! gravidade

t = np.arange(0,10+dt, dt)   #! array como todos os tempos de dt em dt desde 0 até 3 + dt segundos

y = np.zeros(t.size)    #! array inicializado para colocar os y´s
x = np.zeros(t.size)    #! array inicializado para colocar os x´s

vx = np.zeros(t.size)   #! array inicializado para colocar as velocidades de x
vy = np.zeros(t.size)   #! array inicializado para colocar as velocidades de y

ax = np.zeros(t.size)   #! array inicializado para colocar as velocidades de x
ay = np.zeros(t.size)   #! array inicializado para colocar as velocidades de y

G= 4*np.pi**2   #! ter atenção as unidades

M= 1

vx[0]=0
vy[0]= 2*np.pi

x[0]= 1
y[0]=0  



for i in range(0,t.size-1):   #! método de euler  #!exercício d
    mr= np.sqrt(x[i]**2+y[i]**2)
    ax[i] = -G*M/mr**3*x[i]   #! incialização das 2 acelarações
    ay[i] = -G*M/mr**3*y[i]
    vx[i+1] = vx[i]+ax[i]*dt
    vy[i+1] = vy[i]+ay[i]*dt
    x[i+1] = x[i]+vx[i]*dt
    y[i+1] = y[i]+vy[i]*dt
  


plt.title("Orbita da Terra á volta do Sol")
plt.plot(x,y)
plt.show()