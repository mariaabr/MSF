# -*- coding: utf-8 -*-
"""
Created on Tue May 31 00:53:23 2022

@author: tiago
"""
import numpy as np


dt=0.001 # INPUT
tf=4.0
t0=0
n=np.int((tf-t0)/dt+0.1)
print('n = ',n)
t=np.zeros(n+1)
vy=np.zeros(n+1)
y=np.zeros(n+1)
vx=np.zeros(n+1)
x=np.zeros(n+1)
g=9.80
v0y=0
y0=0
v0x=0
x0=0
t[0]=t0
vy[0]=v0y
y[0]=y0
vx[0]=v0x
x[0]=x0
vt=100*1000/3600  # m/s
v0=100*1000/3600  # m/s
theta=10*np.pi/180  # rad
vx[0] = v0*np.cos(theta)
vy[0] = v0*np.sin(theta)


ax = 0
ay = g
x
for i in range(t.size-1):
    vx[i+1] = vx[i] + ax * dt
    vy[i+1] = vy[i] + ay * dt
    x[i+1] = x[i] + vx[i] * dt
    y[i+1] = y[i]+ vy[i] * dt
  