# -*- coding: utf-8 -*-
"""
Created on Tue May 31 18:11:34 2022

@author: tiago
"""

import numpy as np
import matplotlib.pyplot as plt

dt=0.001
tf=1.00
n=np.int(tf/dt+0.1)

t=np.linspace(0,tf,n)


g=9.80      # m/s**2
vt=100*1000/3600  # m/s
vel0=100*1000/3600  # m/s
theta=10*np.pi/180  # rad
v0x=vel0*np.cos(theta)
v0y=vel0*np.sin(theta)
x0=0
y0=0



vel=np.empty(n)
y=np.empty(n)
vx=np.empty(n)
x=np.empty(n)
ax=np.empty(n)
ay=np.empty(n)
vx=np.empty(n)
vy=np.empty(n)
energia=np.empty(n)
vx[0]=v0x
vy[0]=v0y
x[0]=x0
y[0]=y0
massa=0.057

D=g/vt**2

for i in range(0,n-1):
    vel=np.sqrt(vx[i]**2+vy[i]**2)
    ax[i]=-D*vel*vx[i]
    ay[i]=-D*vel*vy[i]-g
    vx[i+1]=vx[i]+ax[i]*dt
    vy[i+1]=vy[i]+ay[i]*dt
    x[i+1]=x[i]+vx[i]*dt
    y[i+1]=y[i]+vy[i]*dt
    energia[i]=0.5*massa*vel**2+massa*g*y[i]
    if (i==0):
        stringPrint=str()+" "+str(energia[i])
        print ("T: {:.2f} s  E_m:{:.2f} J".format(t[i],energia[i]))
    if (t[i]<0.4 and t[i+1]>0.4):
        print ("T: {:.2f} s  E_m:{:.2f} J".format(t[i],energia[i]))
    if (t[i]<0.8 and t[i+1]>0.8):
        print ("T: {:.2f} s  E_m:{:.2f} J".format(t[i],energia[i]))
        
        
#Calcular o ultimo valor da energia mecanica:
vel=np.sqrt(vx[i+1]**2+vy[i+1]**2)
energia[i+1]=0.5*massa*vel**2+massa*g*y[i+1]




plt.figure()
plt.subplot(2, 1, 1)
plt.title(' Trajetória Bola de Ténis com resistência do ar - Euler dt=0.001 s')
plt.ylabel('Y)')
plt.xlabel( 'x' )
plt.plot(x,y,'c')
plt.grid()
plt.subplot(2, 1, 2)

plt.title(' Energia Mecânica (t) - Euler dt=0.001 s')
plt.ylabel('Em (J)')
plt.xlabel( 't (s)' )
plt.plot(t,energia,'c')
plt.grid()
plt.show()
