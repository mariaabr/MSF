# -*- coding: utf-8 -*-
"""
Created on Tue May 31 18:07:47 2022

@author: tiago
"""

import numpy as np
import matplotlib.pyplot as plt



dt=0.001
tf=1.00
n=np.int(tf/dt+0.1)
print('n',n)


  
t=np.empty(n+1)
vy=np.empty(n+1)
ay=np.empty(n+1)
y=np.empty(n+1)
vx=np.empty(n+1)
ax=np.empty(n+1)
x=np.empty(n+1)
energia=np.zeros(n+1)


g=9.80      # m/s**2
vt=100*1000/3600  # m/s
vel0=100*1000/3600  # m/s
theta=np.deg2rad(10)  # rad
massa=0.057

v0x=vel0*np.cos(theta)
v0y=vel0*np.sin(theta)
x0=0
y0=0


t[0]=0
vx[0]= v0x
vy[0]= v0y
x[0]= x0
y[0]= y0

for i in range(n):
    #print('i=',i)
    t[i+1]=t[i]+dt
    vel=np.sqrt(vx[i]**2+vy[i]**2)
    ax[i]=0
    ay[i]=-g     # para teste
    vx[i+1]=vx[i]+ax[i]*dt  
    vy[i+1]=vy[i]+ay[i]*dt        
    x[i+1]=x[i]+vx[i]*dt  
    y[i+1]=y[i]+vy[i]*dt  
    energia[i]=0.5*massa*vel**2+massa*g*y[i]


#Calcular o ultimo valor da energia mecanica:
    
energia[i+1]=0.5*massa*(np.sqrt(vx[i+1]**2+vy[i+1]**2))**2+massa*g*y[i+1]
# print(energia)
# energ=0.5*massa*vel**2+massa*g*y
print(np.mean(energia))
plt.figure()
plt.subplot(2, 1, 1)
# plt.title(' Trajetória Bola de Ténis sem resistência do ar - Euler dt=0.001 s')
plt.ylabel('Y)')
plt.xlabel( 'x' )
plt.plot(x,y,'c')
plt.grid()
plt.figure()


# plt.title('Energia Mecânica (t) - Euler dt=0.001 s')
plt.ylabel('Em (J)')
plt.xlabel( 't (s)' )
plt.plot(t,energia,'c')
plt.grid()
plt.show()
