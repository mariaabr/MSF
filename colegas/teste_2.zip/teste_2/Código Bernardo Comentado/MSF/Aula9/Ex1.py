# -*- coding: utf-8 -*-
"""
Created on Mon May 23 11:18:52 2022

@author: draki
"""
#a
print(30/3.6)
# potencia do ciclista Pcic = (Cres/2)*A*Par*v**2 + umg) * v :: sendo que o u e o cres. do alcatrao 
print((0.9/2*0.6*1.225*8.33**2+0.04*75*9.8)*8.33)

#b
print(40/3.6)
# potencia do ciclista Pcic = (Cres/2)*A*Par*v**2 + umg) * v :: sendo que o u e o cres. do alcatrao 
print((0.9/2*0.6*1.225*11.11**2+0.04*75*9.8)*11.11)

