
# -*- coding: utf-8 -*-
"""

@author: cdazevedo
"""

#a)

import numpy as np
import matplotlib.pyplot as plt


# def maximo(xm1,xm2,xm3,ym1,ym2,ym3):
#     xab=xm1-xm2
#     xac=xm1-xm3
#     xbc=xm2-xm3

#     a=ym1/(xab*xac)
#     b=-ym2/(xab*xbc)
#     c=ym3/(xac*xbc)

#     xmla=(b+c)*xm1+(a+c)*xm2+(a+b)*xm3
#     xmax=0.5*xmla/(a+b+c)

#     xta=xmax-xm1
#     xtb=xmax-xm2
#     xtc=xmax-xm3

#     ymax=a*xtb*xtc+b*xta*xtc+c*xta*xtb
#     return xmax, ymax

    
    
    

# def emptyv(xm1,xm2,xm3,ym1,ym2,ym3):  # raiz pelo polinómio de Lagrange
#     xab=xm1-xm2
#     xac=xm1-xm3
#     xbc=xm2-xm3

#     a=ym1/(xab*xac)
#     b=-ym2/(xab*xbc)
#     c=ym3/(xac*xbc)

#     am=a+b+c
#     bm=a*(xm2+xm3)+b*(xm1+xm3)+c*(xm1+xm2)
#     cm=a*xm2*xm3+b*xm1*xm3+c*xm1*xm2

#     xzero=(bm+np.sqrt(bm*bm-4*am*cm))/(2*am)
#     if xm3 > xm1 and (xzero < xm1 or xzero > xm3): 
#         xzero=(bm-np.sqrt(bm*bm-4*am*cm))/(2*am)


#     if xm1 > xm3 and (xzero < xm3 or xzero > xm1):
#         xzero=(bm-np.sqrt(bm*bm-4*am*cm))/(2*am)

#     xta=xzero-xm1
#     xtb=xzero-xm2
#     xtc=xzero-xm3
#     yzero=a*xtb*xtc+b*xta*xtc+c*xta*xtb
#     return xzero, yzero


dt=0.00001
tf=2.000
n=int(tf/dt+0.1)# penso que este 0.1, o que faz é no máximo adicionar mais um inteiro caso o resultado de tf/dt seja x0.4...

t=np.linspace(0,tf,n)


vy=np.empty(n+1)
y=np.empty(n+1)
vx=np.empty(n+1)
x=np.empty(n+1)
vz=np.empty(n+1)
z=np.empty(n+1)
ax=np.empty(n+1)
ay=np.empty(n+1)
az=np.empty(n+1)



g=9.80      # m/s**2
vt=100*1000/3600  # velocidade terminal m/s
vel0=130*1000/3600  # m/s
theta=10*np.pi/180  # rad
v0x=vel0*np.cos(theta)
v0y=vel0*np.sin(theta)
v0z=0
x0=-10
y0=1
z0=0

vx[0]=v0x
vy[0]=v0y
vz[0]=v0z
x[0]=x0
y[0]=y0
z[0]=z0


D=g/vt**2
omega=100
massa=0.057
raio=0.067/2
area=np.pi*raio**2
den=1.225
mag=0.5*den*area*raio/massa

#vetorOmega=[0,0,100]

for i in range(n):
    vv=np.sqrt(vx[i]**2+vy[i]**2)
    amx=-mag*omega*vy[i]
    amy=mag*omega*vx[i]
       
    
    ax[i]=-D*vv*vx[i] + amx
    ay[i]=-D*vv*vy[i]-g + amy
    az[i]=0
    vx[i+1]=vx[i]+ax[i]*dt  
    vy[i+1]=vy[i]+ay[i]*dt 
    vz[i+1]=vz[i]+az[i]*dt             
    x[i+1]=x[i]+vx[i]*dt  
    y[i+1]=y[i]+vy[i]*dt 
    z[i+1]=z[i]+vz[i]*dt  
    if i>1 and y[i-1] < y[i] and  y[i+1] < y[i]  :
        print('sucess',i, y[i-1], y[i], y[i+1])
        #NOTA: Em 2022 nao foi lecionado o polinomio de lagrange
        #maxx, maxy=maximo(x[i-1], x[i], x[i+1], y[i-1], y[i], y[i+1])
        #print('maximo=',maxx,maxy)
    if i>1 and y[i-1]*y[i] < 0 :   # condição de passagem de y positivo para y negativo
        print('sucess solo:',i, t[i], ' alcance = ',x[i],'solo = ',y[i])
        #NOTA: Em 2022 nao foi lecionado o polinomio de lagrange
        #zerxx, zeryy=emptyv(x[i-1], x[i], x[i+1], y[i-1], y[i], y[i+1])
        #print('alcance =',zerxx,zeryy)


fig, ax1=plt.subplots(1)
#ax1= fig.add_subplot(projection='3d')
##ax.set_xticks(np.arange(-5, 20,1))
# ax1.set_xlabel( 't (m)' )
#ax1.set_ylabel( 'y(t) (m)' )
ax1.plot(x,y)
#ax1.plot(y,z)
#ax1.plot(t,x)
#ax1.plot(t,y,label='y(t)')
#ax1.plot(t,z,label='z(t)')

# plt.legend()
plt.grid()
plt.show()
ax1.set_title( 'Bola sem rotação    (x,y,z) em função do tempo ')


